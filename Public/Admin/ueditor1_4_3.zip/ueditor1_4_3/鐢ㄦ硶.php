
		<script type="text/javascript" charset="utf-8" src="{{__PUBLIC__}}/ueditor1_4_3/ueditor.config.js"></script>
		<script type="text/javascript" charset="utf-8" src="{{__PUBLIC__}}/ueditor1_4_3/ueditor.all.min.js"> </script>
		<script type="text/javascript" charset="utf-8" src="{{__PUBLIC__}}/ueditor1_4_3/lang/zh-cn/zh-cn.js"></script>
		<script id="editor" type="text/plain" style="width:100%;height:500px;" name="content"></script>
		<script>
    		var ue = UE.getEditor('editor');
		</script>